# docveda
AS we know there are 3 ways for treatment
1. HOMEOPATHY 
2. ALLOPATHY 
3. AYURVEDA – Ayurveda stresses a balance of three elemental energies or Vāyu  (air & space – “wind”), pitta (fire & water – “bile”) and Kapha (water & earth – “phlegm”). According to ayurvedic medical theory,  health is a balance of these 3 substances. In the fast-moving ers    where people prefer drugs  without knowing its side effect as to make them cure soon,so our app/web portal is all about Ayurveda's natural cure beauty,  to make u connected to your health and aware about Ayurveda and its importance in today's speedy world  ,through single hashtag so  
our application will provide u all reliable and relevant information about the specific categories topic of Ayurveda news  in the summarised way "read less get more "
where information will be linked to the doctor's articles, research, blogs, new medical updates, ayurvedic news and other relevant information related to Ayurveda. thoughts single hashtag
Feature

◉ Introducing SEARCH for easier access to information

◉ Ayurvedic News Reader – Read Summaries of updated

◉ My Feed – A feed of the latest stories and other content personalized only for you!
